<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Khadija's Arena</title>
  <link rel="stylesheet" href="css/game.css">
  <link rel="stylesheet" href="css/hud.css">
  <link rel="stylesheet" href="css/menu.css">
</head>
<body>
  <canvas id="c"></canvas>

  <div id="hud">
    <style>
      @keyframes radar-spin { from { transform: translateY(-50%) rotate(0deg); } to { transform: translateY(-50%) rotate(360deg); } }
    </style>
    
    <div id="minimap-wrap" style="position: absolute; top: 20px; left: 20px; width: 140px; height: 140px; border-radius: 50%; border: 3px solid #00d4ff; background: rgba(0, 15, 30, 0.7); box-shadow: 0 0 15px rgba(0, 212, 255, 0.4); overflow: hidden; z-index: 10;">
      <canvas id="minimap" width="140" height="140" style="position: absolute; top: 0; left: 0; z-index: 1;"></canvas>
      <div style="position: absolute; top: 50%; left: 50%; width: 50%; height: 2px; background: linear-gradient(90deg, rgba(0,212,255,0), #00d4ff); transform-origin: left center; animation: radar-spin 2s linear infinite; z-index: 2;"></div>
    </div>
    
    <div id="crosshair">
      <div class="ch ch-t"></div><div class="ch ch-b"></div>
      <div class="ch ch-l"></div><div class="ch ch-r"></div>
    </div>
    <div id="damage-indicators-container" style="position: absolute; top: 50%; left: 50%; width: 0; height: 0; z-index: 10; pointer-events: none;"></div>
    <div id="hit-marker">
      <div class="hm hm-tl"></div><div class="hm hm-tr"></div>
      <div class="hm hm-bl"></div><div class="hm hm-br"></div>
    </div>
    <div id="kills-display" style="position: absolute; top: 20px; right: 20px; color: #fff; font-family: sans-serif; font-size: 20px; font-weight: bold; letter-spacing: 1px; text-shadow: 2px 2px 4px #000; z-index: 10;">0 KILLS</div>
    <div id="health-wrap">
      <span id="health-icon">♥</span>
      <div id="health-bar-bg"><div id="health-fill"></div></div>
      <span id="health-label">100</span>
    </div>
    <div id="score-display" style="position: absolute; top: 60px; right: 20px; text-align: right; color: #ffaa00; font-family: sans-serif; font-size: 38px; font-weight: bold; letter-spacing: 2px; text-shadow: 3px 3px 0 #000; z-index: 10;">
      0 <span style="font-size: 20px; color: #fff;">PTS</span>
    </div>
    
    <div id="round-counter-wrap" style="position: absolute; top: 20px; left: 50%; transform: translateX(-50%); color: #fff; font-family: sans-serif; font-size: 24px; font-weight: bold; letter-spacing: 2px; text-shadow: 2px 2px 4px #000; z-index: 10;">
      ROUND: <span id="round-num" style="color: #ff2200;">1</span>
    </div>

    <div id="wave-banner" style="display: none; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%); color: #ff2200; font-family: sans-serif; font-size: 48px; font-weight: bold; letter-spacing: 5px; text-shadow: 3px 3px 6px #000; z-index: 10; pointer-events: none; text-align: center; animation: pulse 1.5s infinite;">
      WAVE 1 BEGINS
    </div>
    <div id="interaction-prompt" style="
      display: none; 
      position: absolute; 
      top: 58%; 
      left: 50%; 
      transform: translate(-50%, -50%); 
      color: #00d4ff; 
      font-family: sans-serif; 
      font-weight: bold; 
      text-shadow: 2px 2px 4px #000; 
      font-size: 18px; 
      pointer-events: none;
      z-index: 10;">
      Press [E] to pick up Weapon
    </div>
    <div id="ammo-wrap">
      <div id="weapon-name">AR · 15</div>
      <div id="ammo-current">30</div>
      <div id="ammo-reserve">/ 90</div>
    </div>
    <div id="reload-wrap">
      <div id="reload-label">RELOADING</div>
      <div id="reload-bar-bg"><div id="reload-bar"></div></div>
    </div>
    <div id="damage-flash"></div>
  </div>

  <div id="floating-texts-container" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 3; overflow: hidden;"></div>	

  <div id="menu">
    <div id="menu-title">KHADIJA ARENA</div>
    <div id="menu-sub">Zombie-style . HTML5</div>
    <div id="controls-grid">
      <div class="key-info"><span class="key-badge">W A S D</span><span>MOVE</span></div>
      <div class="key-info"><span class="key-badge">MOUSE</span><span>AIM</span></div>
      <div class="key-info"><span class="key-badge">CLICK</span><span>SHOOT</span></div>
      <div class="key-info"><span class="key-badge">R</span><span>RELOAD</span></div>
      <div class="key-info"><span class="key-badge">SPACE</span><span>JUMP</span></div>
      <div class="key-info"><span class="key-badge">SHIFT</span><span>SPRINT</span></div>
      <div class="key-info"><span class="key-badge">R-CLICK</span><span>ADS</span></div>
    </div>
    
    <div style="margin: 20px auto; text-align: center;">
      <select id="map-select" style="padding: 10px 20px; font-size: 16px; background: #111; color: #00d4ff; border: 2px solid #00d4ff; border-radius: 4px; outline: none; cursor: pointer; font-family: sans-serif; font-weight: bold; letter-spacing: 1px;">
        <option value="0">ARENA: The Bunker</option>
        <option value="1">ARENA: The Courtyard</option>
      </select>
    </div>

    <button id="start-btn">▶  PLAY</button>
  </div>

  <div id="death-screen">
    <div id="death-title">YOU DIED</div>
    <div id="death-sub">Eliminations</div>
    <div id="final-kills">0</div>
    <button id="respawn-btn">↺  RESPAWN</button>
  </div>

  <div id="lock-hint">Click to capture mouse</div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>  
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/postprocessing/EffectComposer.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/postprocessing/RenderPass.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/postprocessing/ShaderPass.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/shaders/CopyShader.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/shaders/LuminosityHighPassShader.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/postprocessing/UnrealBloomPass.js"></script>
  <script type="module" src="js/main.js"></script>
</body>
</html>