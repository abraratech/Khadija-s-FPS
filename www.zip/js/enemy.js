// js/enemy.js
import { scene, walls, camera } from './map.js';
import { player, damagePlayer } from './player.js';
import { updateKillsHUD, updateRoundHUD, flashWaveBanner, updateScoreHUD, spawnFloatingScore } from './ui.js';
import { spawnBloodDecal } from './particles.js';
import { giveMaxAmmo } from './weapons.js';
import { playSound } from './audio.js';

export let eMeshList = []; 
export const activeEnemies = [];
const activePowerups = [];

const gBodyGeo = new THREE.BoxGeometry(0.72, 1.15, 0.46);
const gHeadGeo = new THREE.BoxGeometry(0.42, 0.42, 0.42);
const gLegGeo  = new THREE.BoxGeometry(0.28, 0.58, 0.28);
const gArmGeo  = new THREE.BoxGeometry(0.2, 0.54, 0.2);
const skinMat  = new THREE.MeshStandardMaterial({ color: 0xffddaa, roughness: 0.8 });

// ── UPGRADED TEXTURED AUDIO ENGINE (CRUNCH & RUMBLE) ──
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// Create a gritty "white noise" buffer for realistic footstep crunches
const noiseBufferSize = audioCtx.sampleRate * 0.15;
const noiseBuffer = audioCtx.createBuffer(1, noiseBufferSize, audioCtx.sampleRate);
const output = noiseBuffer.getChannelData(0);
for (let i = 0; i < noiseBufferSize; i++) output[i] = Math.random() * 2 - 1;

function playSpatialZombieSound(ePos, type, isFootstep = true) {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const dist = player.pos.distanceTo(ePos);
  if (dist > 18) return; 
  
  const camDir = new THREE.Vector3(); camera.getWorldDirection(camDir); camDir.y = 0; camDir.normalize();
  const toEnemy = new THREE.Vector3().subVectors(ePos, player.pos); toEnemy.y = 0; toEnemy.normalize();
  const rightVec = new THREE.Vector3().crossVectors(camDir, new THREE.Vector3(0, 1, 0)).normalize();
  const panX = toEnemy.dot(rightVec);
  
  const vol = Math.max(0, 1 - (dist / 18)) * (type === "GOLIATH" ? 1.5 : 0.6);

  const gain = audioCtx.createGain();
  const panner = audioCtx.createStereoPanner ? audioCtx.createStereoPanner() : null;

  if (panner) { panner.pan.value = panX; gain.connect(panner); panner.connect(audioCtx.destination); } 
  else { gain.connect(audioCtx.destination); }

  if (isFootstep) {
    // Crunching Footstep Math
    const source = audioCtx.createBufferSource(); source.buffer = noiseBuffer;
    const filter = audioCtx.createBiquadFilter(); filter.type = 'lowpass';
    filter.frequency.value = type === "GOLIATH" ? 300 : 800; // Deeper crunch for boss
    source.connect(filter); filter.connect(gain);
    gain.gain.setValueAtTime(vol, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
    source.start();
  } else {
    // Guttural Growl Math
    const osc = audioCtx.createOscillator(); osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(type === "GOLIATH" ? 30 : 60, audioCtx.currentTime);
    const filter = audioCtx.createBiquadFilter(); filter.type = 'lowpass';
    filter.frequency.setValueAtTime(type === "GOLIATH" ? 100 : 200, audioCtx.currentTime);
    filter.frequency.linearRampToValueAtTime(40, audioCtx.currentTime + 0.5);
    osc.connect(filter); filter.connect(gain);
    gain.gain.setValueAtTime(vol * 0.8, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
    osc.start(); osc.stop(audioCtx.currentTime + 0.5);
  }
}

// ── WAVE SYSTEM ──
export let currentWave = 1; let zombiesToSpawnThisRound = 0; let zombiesSpawnedSoFar = 0; let goliathsToSpawn = 0; let spawnTimer = 0;

const ENEMY_TYPES = {
  SHAMBLER: { name: "SHAMBLER", speed: 2.4, maxHealth: 100, damage: 15, attackCooldown: 1.4, attackRange: 1.4, colRadius: 0.45, color: 0x446644, scale: new THREE.Vector3(1, 1, 1) },
  RUNNER:   { name: "RUNNER", speed: 5.2, maxHealth: 65, damage: 10, attackCooldown: 0.8, attackRange: 1.4, colRadius: 0.40, color: 0x883333, scale: new THREE.Vector3(0.85, 1.05, 0.85) },
  GOLIATH:  { name: "GOLIATH", speed: 1.6, maxHealth: 1500, damage: 45, attackCooldown: 2.2, attackRange: 3.2, colRadius: 1.20, color: 0x1a1a1a, scale: new THREE.Vector3(2.5, 2.5, 2.5) } 
};

const POWERUP_TYPES = [
  { name: 'MAX AMMO', color: 0x00ff00 }, { name: 'INSTA-KILL', color: 0xffaa00 }, { name: 'DOUBLE POINTS', color: 0xffff00 }, { name: 'NUKE', color: 0xff0000 }
];

export function initEnemies() {
  activeEnemies.forEach(e => scene.remove(e.mesh)); activeEnemies.length = 0; eMeshList.length = 0;
  activePowerups.forEach(p => scene.remove(p.mesh)); activePowerups.length = 0;
  currentWave = 1; startWave(currentWave);
}

function startWave(waveNumber) {
  zombiesSpawnedSoFar = 0; spawnTimer = 0;
  if (waveNumber > 0 && waveNumber % 5 === 0) {
    goliathsToSpawn = Math.floor(waveNumber / 5); 
    zombiesToSpawnThisRound = 4 + (waveNumber * 2) + goliathsToSpawn; 
    flashWaveBanner(`BOSS ROUND ${waveNumber}`);
  } else {
    goliathsToSpawn = 0; zombiesToSpawnThisRound = 4 + (waveNumber * 2); flashWaveBanner(`ROUND ${waveNumber}`);
  }
  updateRoundHUD(waveNumber);
}

function spawnZombie() {
  let config;
  if (goliathsToSpawn > 0) { config = ENEMY_TYPES.GOLIATH; goliathsToSpawn--; } 
  else { config = Math.random() < Math.min(0.50, 0.10 + (currentWave * 0.05)) ? ENEMY_TYPES.RUNNER : ENEMY_TYPES.SHAMBLER; }

  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: config.color, roughness: 0.65, metalness: config.name === "GOLIATH" ? 0.4 : 0.1 });
  
  const body = new THREE.Mesh(gBodyGeo, mat); body.position.y = 1.08; g.add(body);
  const head = new THREE.Mesh(gHeadGeo, skinMat); head.position.y = 1.9; g.add(head);
  const legL = new THREE.Mesh(gLegGeo, mat); legL.position.set(-0.17, 0.29, 0); g.add(legL);
  const legR = new THREE.Mesh(gLegGeo, mat); legR.position.set(0.17, 0.29, 0); g.add(legR);
  const armL = new THREE.Mesh(gArmGeo, mat); armL.position.set(-0.48, 1.04, 0); g.add(armL);
  const armR = new THREE.Mesh(gArmGeo, mat); armR.position.set(0.48, 1.04, 0); g.add(armR);
  
  // ── FIX: TIGHTENED SAFE SPAWN COORDINATES ──
  const sp = [[-14, -14], [14, -14], [-14, 14], [14, 14], [0, -16], [0, 16], [-16, 0], [16, 0]];
  const [sx, sz] = sp[Math.floor(Math.random() * sp.length)];
  g.position.set(sx + (Math.random() - 0.5) * 2, 0, sz + (Math.random() - 0.5) * 2);
  
  g.scale.copy(config.scale); scene.add(g);

  const enemyInstance = { 
    mesh: g, type: config.name, health: config.maxHealth, maxHealth: config.maxHealth, speed: config.speed + (Math.random() - 0.5) * 0.4 + (currentWave * 0.1),
    damage: config.damage, attackRate: config.attackCooldown, atkCD: Math.random() * config.attackCooldown, attackRange: config.attackRange, colRadius: config.colRadius, 
    walkT: Math.random() * Math.PI * 2, dyingT: -1, alive: true
  };

  body.userData.eRef = enemyInstance; head.userData.eRef = enemyInstance; head.userData.isHead = true;
  activeEnemies.push(enemyInstance); zombiesSpawnedSoFar++; rebuildEMeshList();
}

function rebuildEMeshList() {
  eMeshList = [];
  activeEnemies.forEach(e => {
    if (!e.alive || e.dyingT >= 0) return;
    e.mesh.children.forEach(child => { if (child.isMesh) { if (!child.userData.eRef) child.userData.eRef = e; eMeshList.push(child); } });
  });
}

const _eToP = new THREE.Vector3();

export function updateEnemies(dt) {
  if (!player.alive) return;

  // Powerup updates
  for (let i = activePowerups.length - 1; i >= 0; i--) {
    const p = activePowerups[i];
    p.mesh.rotation.y += dt * 2.5; p.mesh.position.y = 0.8 + Math.sin(Date.now() * 0.005) * 0.15; p.life -= dt;
    if (p.life <= 0) { scene.remove(p.mesh); activePowerups.splice(i, 1); continue; }
    if (player.pos.distanceTo(p.mesh.position) < 1.6) {
      flashWaveBanner(p.type.name, 2500); playSound('hit', 1.0, false);
      if (p.type.name === 'MAX AMMO') giveMaxAmmo();
      if (p.type.name === 'INSTA-KILL') player.instaKillTimer = 15.0;
      if (p.type.name === 'DOUBLE POINTS') player.doublePointsTimer = 30.0;
      if (p.type.name === 'NUKE') {
        player.score += 400; updateScoreHUD(player.score); spawnFloatingScore(400, false);
        activeEnemies.forEach(z => { if (z.alive) { z.alive = false; z.dyingT = 0; player.kills++; spawnBloodDecal(z.mesh.position); } });
        updateKillsHUD(player.kills); rebuildEMeshList();
      }
      scene.remove(p.mesh); activePowerups.splice(i, 1);
    }
  }

  if (zombiesSpawnedSoFar < zombiesToSpawnThisRound) {
    spawnTimer += dt; if (spawnTimer >= 1.0) { spawnZombie(); spawnTimer = 0; }
  }

  for (const e of activeEnemies) {
    if (e.dyingT >= 0) {
      e.dyingT += dt; const t = Math.min(e.dyingT / 0.45, 1);
      e.mesh.scale.y = (1 - t) * (e.type === "GOLIATH" ? 2.5 : (e.type === "RUNNER" ? 1.05 : 1)); e.mesh.position.y = -t * 0.5; continue;
    }
    if (!e.alive) continue;

    _eToP.set(player.pos.x - e.mesh.position.x, 0, player.pos.z - e.mesh.position.z);
    const dist = _eToP.length();

    if (dist > 0.1) e.mesh.lookAt(player.pos.x, e.mesh.position.y, player.pos.z);

    if (dist > e.attackRange) {
      const oldWalk = e.walkT;
      e.walkT += dt * e.speed * 3.5;
      e.mesh.position.x += (_eToP.x / dist) * e.speed * dt;
      e.mesh.position.z += (_eToP.z / dist) * e.speed * dt;
      
      // ── FIX: ANTI-STUCK / NaN PROTECTION COLLISION MATH ──
      for (const w of walls) {
        const ep = e.mesh.position;
        const cx = Math.max(w.minX, Math.min(ep.x, w.maxX));
        const cz = Math.max(w.minZ, Math.min(ep.z, w.maxZ));
        const ddx = ep.x - cx, ddz = ep.z - cz, d2 = ddx * ddx + ddz * ddz;
        const r = e.colRadius; 
        if (d2 < r * r) { 
          const d = Math.sqrt(d2) || 0.001; // <--- The math fix preventing them from freezing in walls!
          ep.x += (ddx / d) * (r - d); 
          ep.z += (ddz / d) * (r - d); 
        }
      }
      
      const c = e.mesh.children; const amp = e.type === "RUNNER" ? 0.65 : 0.42;
      if (c[2]) c[2].rotation.x = Math.sin(e.walkT) * amp; if (c[3]) c[3].rotation.x = -Math.sin(e.walkT) * amp;
      if (c[4]) c[4].rotation.x = -Math.sin(e.walkT) * (amp * 0.8); if (c[5]) c[5].rotation.x = Math.sin(e.walkT) * (amp * 0.8);
      
      // Trigger new audio
      if (Math.floor(oldWalk / Math.PI) !== Math.floor(e.walkT / Math.PI)) playSpatialZombieSound(e.mesh.position, e.type, true);
      if (Math.random() < 0.005) playSpatialZombieSound(e.mesh.position, e.type, false);
    }

    e.atkCD -= dt;
    if (dist <= e.attackRange && e.atkCD <= 0 && player.alive) {
      e.atkCD = e.attackRate; damagePlayer(e.damage, e.mesh.position);
      e.mesh.position.x += (_eToP.x / dist) * 0.15; e.mesh.position.z += (_eToP.z / dist) * 0.15;
    }
  }
}

export function killEnemy(e) {
  if (!e.alive) return;
  e.alive = false; e.dyingT = 0; 
  spawnBloodDecal(e.mesh.position);
  player.kills++; updateKillsHUD(player.kills); rebuildEMeshList(); 
  
  if (Math.random() < 0.10) {
    const type = POWERUP_TYPES[Math.floor(Math.random() * POWERUP_TYPES.length)];
    const pMesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.35), new THREE.MeshStandardMaterial({ color: type.color, emissive: type.color, emissiveIntensity: 0.8 }));
    pMesh.position.copy(e.mesh.position); pMesh.position.y = 0.8; scene.add(pMesh); activePowerups.push({ mesh: pMesh, type: type, life: 15.0 });
  }
  
  setTimeout(() => {
    scene.remove(e.mesh);
    const instanceIdx = activeEnemies.indexOf(e);
    if (instanceIdx !== -1) activeEnemies.splice(instanceIdx, 1);
    
    if (zombiesSpawnedSoFar >= zombiesToSpawnThisRound && activeEnemies.length === 0) {
      currentWave++; flashWaveBanner("ROUND CLEAR", 2500);
      setTimeout(() => { if (player.alive) startWave(currentWave); }, 5000);
    }
  }, 600);
}
// At the absolute BOTTOM of js/enemy.js, replace getActiveEnemies with this:
export function getActiveEnemies() { 
  return activeEnemies; 
}