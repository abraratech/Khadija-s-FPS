// js/main.js
import { renderer, scene, camera, buildMap, composer, applyScreenShake } from './map.js';
import { player, updatePlayer, EYE_H } from './player.js';
import { initEnemies, updateEnemies, getActiveEnemies } from './enemy.js';
import { updateHealthHUD, updateAmmoHUD, updateKillsHUD, updateUIEffects, updateScoreHUD, updateMinimap } from './ui.js';
import { buildGun, updateGun, shoot, startReload, processReloadTick, cycleWeapon, checkWorldInteractions, getActiveWeapon, resetGunState } from './weapons.js';
import { initAudio } from './audio.js';
import { updateParticles, clearAllDecals } from './particles.js';

const canvas = document.getElementById('c');

// ════════════ INPUT STATE ════════════
const keys = {};
let mdx = 0, mdy = 0, locked = false, pendingShot = false;

window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'KeyR' && gs === 'playing' && player.alive) startReload();
  if (e.code === 'ShiftLeft') player.isSprinting = true;
  if (e.code === 'KeyQ' && gs === 'playing' && player.alive) cycleWeapon();
  if (e.code === 'KeyE' && gs === 'playing' && player.alive) checkWorldInteractions(true); 

  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
});

window.addEventListener('keyup', e => { 
  keys[e.code] = false; 
  if (e.code === 'ShiftLeft') player.isSprinting = false;
});

window.addEventListener('mousemove', e => { 
  if (locked) { mdx += e.movementX; mdy += e.movementY; } 
});

window.addEventListener('mousedown', e => { 
  if (gs !== 'playing' || !locked || !player.alive) return;
  const activeW = getActiveWeapon();
  if (activeW && activeW.reloading) return; // Prevent shooting while reloading

  if (e.button === 0) {
    keys['MousedownLeft'] = true; 
    pendingShot = true; 
  }
  if (e.button === 2) player.isADS = true; 
});

window.addEventListener('mouseup', e => { 
  if (e.button === 0) keys['MousedownLeft'] = false;
  if (e.button === 2) player.isADS = false; 
});

window.addEventListener('contextmenu', e => e.preventDefault());

document.addEventListener('pointerlockchange', () => {
  locked = document.pointerLockElement === canvas;
  document.getElementById('lock-hint').style.display = locked ? 'none' : 'block';
  if (!locked) { player.isADS = false; player.isSprinting = false; keys['MousedownLeft'] = false; }
});

canvas.addEventListener('click', () => { 
  if (gs === 'playing' && !locked) canvas.requestPointerLock(); 
});

// ════════════ GAME LOOP ════════════
let gs = 'menu', prev = 0;

function tick(t = 0) {
  requestAnimationFrame(tick);
  
  const dt = Math.min((t - prev) * 0.001, 0.05); 
  prev = t;
  
  if (gs !== 'playing') { 
    composer.render(); 
    return; 
  }
  
  updatePlayer(dt, keys, mdx, mdy);
  mdx = 0; mdy = 0;

  updateEnemies(dt);
  
  const isMoving = (keys['KeyW'] || keys['KeyS'] || keys['KeyA'] || keys['KeyD']) && player.onGround;
  updateGun(dt, keys, isMoving);
  
  checkWorldInteractions(false); 

  if (pendingShot) { 
    shoot(); 
    pendingShot = false; 
  }
  
  updateParticles(dt);
  updateUIEffects(dt);
  processReloadTick(dt);

  if (!player.alive && gs === 'playing') {
    gs = 'dead';
    document.getElementById('final-kills').textContent = player.kills;
    setTimeout(() => { document.getElementById('death-screen').style.display = 'flex'; }, 700);
  }
  const camDir = new THREE.Vector3();
  camera.getWorldDirection(camDir);
  updateMinimap(player.pos, camDir, getActiveEnemies());
  applyScreenShake(dt); // ◄── Add this line to violently shake the camera if needed
  composer.render();
}

// ════════════ INIT / RESPAWN ════════════

document.getElementById('start-btn').addEventListener('click', () => {
  document.getElementById('menu').style.display = 'none';
  document.getElementById('hud').style.display = 'block';
  
  const chosenMap = parseInt(document.getElementById('map-select').value) || 0;
  buildMap(chosenMap);
  
  scene.add(camera); 
  initAudio();
  
  resetGunState();
  initEnemies();
  
  updateHealthHUD(player.health); 
  updateAmmoHUD(getActiveWeapon().ammo, getActiveWeapon().reserve); 
  updateKillsHUD(player.kills);
  updateScoreHUD(player.score);
  
  gs = 'playing'; 
  canvas.requestPointerLock();
  requestAnimationFrame(tick); // THIS starts the engine!
});

function respawnPlayer() {
  const activeW = getActiveWeapon();
  if (activeW && activeW.meshGroup) {
    camera.remove(activeW.meshGroup);
  }

  const chosenMap = parseInt(document.getElementById('map-select').value) || 0;
  buildMap(chosenMap);

  player.pos.set((Math.random() - 0.5) * 8, EYE_H, (Math.random() - 0.5) * 8); 
  player.vel.set(0, 0, 0); 
  player.yaw = Math.random() * Math.PI * 2;
  player.health = 100; 
  player.kills = 0; 
  player.score = 0; 
  player.instaKillTimer = 0;
  player.doublePointsTimer = 0;
  player.alive = true; 
  
  resetGunState();
  initEnemies(); 
  clearAllDecals();
  
  updateHealthHUD(player.health); 
  updateAmmoHUD(getActiveWeapon().ammo, getActiveWeapon().reserve); 
  updateKillsHUD(player.kills);
  updateScoreHUD(player.score); 
  
  document.getElementById('damage-flash').style.opacity = '0';
  document.getElementById('death-screen').style.display = 'none';
  
  gs = 'playing'; 
  canvas.requestPointerLock();
}

document.getElementById('respawn-btn').addEventListener('click', respawnPlayer);